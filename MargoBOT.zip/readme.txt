                  Automatyczny bot do Margonem — E2
                             wersja: 1.0.0

		W CELU ZAKUPU LICENCJI SKONTAKTUJ SIĘ
		  ZE MNĄ POPRZEZ DISCORDA 'XANKEEM'

───────────────────────────────────────────────────────────────────────

📌 OPIS:

MargoBOT to automatyczny asystent do gry Margonem, stworzony z myślą o 
efektywnym zabijaniu elit 2. Bot automatycznie:
- podchodzi do elity 2,
- leczy postać,
- system logów,
- odświeża stronę co 10 minut.

Przeznaczony wyłącznie do **starego interfejsu** Margonem.

───────────────────────────────────────────────────────────────────────

⚠️ WAŻNE INSTRUKCJE:

1. **Logowanie do gry**
   - Zaloguj się na konto tylko przez przeglądarkę, która uruchomi się 
     automatycznie po włączeniu `MargoBOT.exe`.
   - NIE używaj zewnętrznych przeglądarek (np. Chrome, Firefox).

2. **Aktualizacja bota**
   - Aby zaktualizować bota do najnowszej wersji, uruchom plik:
     `updater.exe`.

3. **Interfejs gry**
   - Bot działa wyłącznie na **starym interfejsie** Margonem.
     (Nowy interfejs nie jest wspierany).

───────────────────────────────────────────────────────────────────────

✅ POLECANE DODATKI:

Aby w pełni wykorzystać potencjał bota, zainstaluj poniższe dodatki dostępne w oficjalnym repozytorium dodatków Margonem:

🔹 **Loot Filter by cLAsick**  
   Umożliwia filtrowanie łupów, ukrywanie śmieciowych przedmiotów  
   i automatyczne zbieranie wartościowego lootu.

🔹 **Szybka walka automatyczna**  
   Usprawnia przebieg walk z potworami — szybciej, bez klikania.  

🔹 **Legendary Notificator**  
   Powiadamia dźwiękowo lub wizualnie o dropie legendarnych przedmiotów.

───────────────────────────────────────────────────────────────────────

📞 WSPARCIE / KONTAKT:

W razie pytań, błędów lub propozycji funkcji, skontaktuj się przez Discord:  
`Xankeem`

───────────────────────────────────────────────────────────────────────

🛑 UŻYWANIE BOTA JEST NA WŁASNĄ ODPOWIEDZIALNOŚĆ!  
Złamanie regulaminu gry może skutkować banem konta.

───────────────────────────────────────────────────────────────────────

Dzięki za korzystanie z MargoBOT!